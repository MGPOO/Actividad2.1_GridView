import 'dart:ui';
import 'package:flutter/material.dart';

class Coche{
  final String marca;
  final String modelo;
  final Image image;

  Coche(this.marca, this.modelo,this.image);
}