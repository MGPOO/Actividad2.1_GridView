import 'package:flutter/material.dart';
import '../models/coche.dart';



class CocheController {
  List<Coche> coches = [

      Coche('Renault', 'Twingo', Image.asset('car1.png')),
      Coche('Citroen', 'CS', Image.asset('car1.png')),
      Coche('Ford', 'F150', Image.asset('car2.png')),
      Coche('Porsche', 'Focus', Image.asset('car3.png')),
      Coche('Ferrari', 'F340', Image.asset('car4.png')),
      Coche('Renault', 'Twingo', Image.asset('car1.png')),
      Coche('Citroen', 'CS', Image.asset('car1.png')),
      Coche('Ford', 'F150', Image.asset('car2.png')),
      Coche('Porsche', 'Focus', Image.asset('car3.png')),
      Coche('Ferrari', 'F340', Image.asset('car4.png')),





  ];
}